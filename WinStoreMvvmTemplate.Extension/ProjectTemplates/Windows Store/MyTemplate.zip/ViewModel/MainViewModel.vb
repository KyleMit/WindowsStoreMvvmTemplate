﻿Imports $safeprojectname$.Utilities

Namespace ViewModel

    Public Class MainViewModel : Inherits BindableBase


    End Class

End Namespace